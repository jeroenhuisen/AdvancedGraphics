//#pragma once

struct Ray {
	float3 origin, direction; //origin, direction
	float t; //distance
};