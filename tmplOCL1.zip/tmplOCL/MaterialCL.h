//#pragma once
/*struct MaterialCL {
	float3 color;
	float reflectioness;
};*/