//#pragma once
//#include "system.h"

struct Material {
	cl_float3 color;
	cl_float reflectioness;
};