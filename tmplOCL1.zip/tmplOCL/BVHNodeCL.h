
struct BVHNodeStruct {
	float3 leftBottom;
	float3 rightTop;

	//int leftFirst;
	//int count; //amount of triangles
	int3 test;
};