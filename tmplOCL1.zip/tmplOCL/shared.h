#define SCRWIDTH			800
#define SCRHEIGHT			480